# 完整演示交付索引

本轮20261026_dbbd8a：三角色业务主线完成；21组PASS、1组报告PDF保存BLOCKED，详见实测报告。

- [完整演示手册PDF](演示手册.pdf) / [可编辑讲稿](演示手册.md)
- [三角色流程图HTML](三角色流程图.html) / [SVG](三角色流程图.svg)
- [MCP实测报告](MCP测试报告.md) / [独立审阅与修复](独立审阅与修复.md)
- [完整输入资料目录](../../../demo_materials/full-system-demo/runs/20261026_dbbd8a/inputs/)
- [真实200张二维码卡PDF](../../../demo_materials/full-system-demo/runs/20261026_dbbd8a/downloads/系统真实月度评价卡.pdf)
- [真实期末报告HTML](../../../demo_materials/full-system-demo/runs/20261026_dbbd8a/downloads/系统真实期末报告.html)
- [截图、接口核对与回归日志](../../../demo_materials/full-system-demo/runs/20261026_dbbd8a/evidence/)

本机启动：项目根目录 `node demo_materials/full-system-demo/start.cjs 20261026_dbbd8a`。入口 http://localhost:5188 ，管理员demo_admin、教师demo_teacher_a、学生demo_s01；本机演示密码Demo123456。

重建起点：`node demo_materials/full-system-demo/initialize.cjs` 创建新run；再以已安装openpyxl/xlsxwriter/Pillow/reportlab的Python执行 `demo_materials/full-system-demo/generate.py 新runId`。保留当前结果库，关闭本任务进程释放专用端口后再启动新run。原backend/.env只读取MySQL连接信息，不改写；私有凭证位于已忽略的.runtime，勿对外打包。

压缩包包含资料、真实产物、证据和生成脚本，排除.runtime、数据库密码、node_modules。报告“PDF”接口实际返回HTML打印视图，浏览器保存PDF仍待核验。独立回归使用专用测试库，勿将现有自动测试直接指向本演示终态库。

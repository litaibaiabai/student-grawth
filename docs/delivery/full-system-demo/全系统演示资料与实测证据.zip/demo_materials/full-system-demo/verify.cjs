// API/DB evidence complements CUA UI tests; never counts as browser interaction.
const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const dir=path.join(__dirname,'runs',fs.readFileSync(path.join(__dirname,'latest-run.txt'),'utf8').trim()),m=JSON.parse(fs.readFileSync(path.join(dir,'manifest.json'))),base='http://localhost:'+m.backendPort+'/api/v1';
const results=[];const tokens={};
async function req(name,url,body,token){const r=await fetch(base+url,{method:body===undefined?'GET':'POST',headers:{...(token?{Authorization:'Bearer '+token}:{}),'Content-Type':'application/json'},...(body!==undefined?{body:JSON.stringify(body)}:{})});const text=await r.text();let data;try{data=JSON.parse(text)}catch{data=text}return {status:r.status,data};}
async function check(name,fn){try{await fn();results.push({name,status:'PASS'})}catch(e){results.push({name,status:'FAIL',actual:e.message})}}
async function main(){
 for(const username of ['demo_admin','demo_teacher_a','demo_teacher_b','demo_s01','demo_s08','other_manager']){const x=await req('', '/auth/login',{username,password:'Demo123456'});assert.equal(x.status,200);tokens[username]=x.data.data.token;}
 const adm=tokens.demo_admin,tea=tokens.demo_teacher_a,tb=tokens.demo_teacher_b,stu=tokens.demo_s01,other=tokens.other_manager;
 const deny=async(name,url,body,token,status=403)=>check(name,async()=>assert.equal((await req(name,url,body,token)).status,status));
 await deny('未登录账本','/student/scores',undefined,undefined,401);
 await deny('学生不能发布','/admin/reports/publish-batch',{studentIds:[11]},stu);
 for(const [name,url,body]of [['荣誉跨班','/teacher/honors/1/review',{decision:'APPROVED'}],['故事跨班','/teacher/stories/1/review',{teacherScore:88.5}],['综合分跨班','/student/comprehensive-score?studentId=11'],['账本跨班','/student/scores?studentId=11'],['报告跨班','/student/reports/current?studentId=11']])await deny(name,url,body,tb);
 for(const [name,url,body]of [['荣誉跨校','/teacher/honors/1/review',{decision:'APPROVED'}],['故事跨校','/teacher/stories/1/review',{teacherScore:88.5}],['综合分跨校','/student/comprehensive-score?studentId=11']])await deny(name,url,body,other);
 await deny('教师Excel跨班确认','/import/batch-commit',{type:'SUBJECT',validStudents:[{studentId:11,scores:[{subjectCode:'CHINESE',score:96}]}]},tb);
 await deny('管理员JSON跨校确认','/import/commit',{type:'SUBJECT',items:[{studentId:11,subjectCode:'CHINESE',score:96}]},other);
 await deny('学生不得覆盖终审故事','/student/stories',{content:'attempted overwrite',monthKey:m.monthKey},stu,409);
 await deny('重复荣誉审核','/teacher/honors/1/review',{decision:'APPROVED'},tea,409);
 await deny('重复故事终审','/teacher/stories/1/review',{teacherScore:88.5},tea,409);
 await deny('重复冲销','/admin/scores/reversal',{originalScoreId:21,reason:'repeat'},adm,409);
 await deny('异校冲销','/admin/scores/reversal',{originalScoreId:20,reason:'cross school'},other);
 await deny('教师不可导六育','/import/batch-preview',{type:'DIMENSION',rows:[{username:'demo_s01',scores:{D:90}}]},tea);
 await check('教师跨班列表隔离',async()=>{for(const ep of ['/honors','/stories'])assert.equal((await req('',ep,undefined,tb)).data.data.length,0)});
 await check('学生忽略他人ID',async()=>assert.equal(Number((await req('','/student/comprehensive-score?studentId=12',undefined,stu)).data.data.studentId),11));
 await check('独立核算90.50和实际规则',async()=>{const x=(await req('','/student/comprehensive-score',undefined,stu)).data.data;assert.equal(x.comprehensiveScore,90.5);assert.equal(x.sixAverage,91.25);assert.equal(x.process.netPoints,20);assert.equal(x.honor.approvedPoints,6);assert.equal(x.dimensions.G,88.5);assert.equal(x.ruleVersion,'DEMO_V1');fs.writeFileSync(path.join(dir,'evidence','api-main-evaluation.json'),JSON.stringify(x,null,2));});
 await check('六维0分合法且均值0',async()=>{const x=(await req('','/student/comprehensive-score',undefined,tokens.demo_s08)).data.data;assert.equal(x.isComplete,true);assert.equal(x.sixAverage,0);assert.equal(x.comprehensiveScore,0)});
 await check('校历日期不偏移',async()=>{const x=(await req('','/terms/current',undefined,adm)).data.data;assert.equal(x.startDate,m.term.startDate);assert.equal(x.endDate,m.term.endDate)});
 await check('真实报告及HTML内容',async()=>{const r=(await req('','/student/reports/current',undefined,stu)).data.data;assert.equal(r.comprehensiveScore,90.5);assert.equal(Number(r.snapshot.subjects.find(s=>s.subject_code==='CHINESE').score),96);const x=await req('','/student/reports/'+r.id+'/export-pdf',undefined,stu);assert.equal(x.status,200);assert.equal(typeof x.data,'string');assert.ok(x.data.includes('90.50')||x.data.includes('90.5'));fs.writeFileSync(path.join(dir,'downloads','系统真实期末报告.html'),x.data);fs.writeFileSync(path.join(dir,'evidence','api-published-report.json'),JSON.stringify(r,null,2));await deny('他人报告禁止导出','/student/reports/'+r.id+'/export-pdf',undefined,tokens.demo_s08);await deny('匿名报告禁止导出','/student/reports/'+r.id+'/export-pdf',undefined,undefined,401);});
 await check('私有证书访问',async()=>{const h=(await req('','/honors',undefined,stu)).data.data[0];const ep='/uploads/'+h.certificate_url;assert.equal((await req('',ep,undefined,stu)).status,200);assert.equal((await req('',ep,undefined,tb)).status,403);assert.equal((await req('',ep,undefined,undefined)).status,401)});
 await check('真实PDF受控下载及匿名拦截',async()=>{const x=await req('','/admin/card-print-packs/1/download',undefined,adm);assert.equal(x.status,200);assert.ok(x.data.startsWith('%PDF-'));assert.equal((await req('','/admin/card-print-packs/1/download',undefined,undefined)).status,401);});
 const cardUrl=fs.readFileSync(path.join(dir,'downloads','真实卡领取链接.txt'),'utf8').trim();
 await deny('已用卡重复预览拒绝','/student/cards/preview',{token:new URLSearchParams(new URL(cardUrl).hash.split('?')[1]).get('token')},stu,409);
 await check('8名学生独立核算表逐项一致',async()=>{
   const lines=fs.readFileSync(path.join(dir,'inputs','09_预期核算.csv'),'utf8').trim().split(/\r?\n/).slice(1);
   for(const line of lines){const a=line.split(',');const u=m.users.find(u=>u.username===a[0]);const x=(await req('','/student/comprehensive-score?studentId='+u.id,undefined,adm)).data.data;assert.equal(x.comprehensiveScore,Number(a[13]));assert.equal(x.sixAverage,Number(a[10]));}
 });
 await check('发布快照不随后续学科更正变化',async()=>{
   const before=(await req('','/student/reports/current',undefined,stu)).data.data;
   try{assert.equal((await req('','/import/commit',{type:'SUBJECT',items:[{studentId:11,subjectCode:'CHINESE',subjectName:'语文',score:97}]},adm)).status,200);
     const after=(await req('','/student/reports/current',undefined,stu)).data.data;
     assert.deepEqual(after.snapshot,before.snapshot);assert.equal(Number(after.snapshot.subjects.find(s=>s.subject_code==='CHINESE').score),96);
   }finally{assert.equal((await req('','/import/commit',{type:'SUBJECT',items:[{studentId:11,subjectCode:'CHINESE',subjectName:'语文',score:96}]},adm)).status,200);}
 });
 const report={runId:m.runId,mode:'API补充验证（非UI）',results};fs.writeFileSync(path.join(dir,'evidence','api-boundaries.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));process.exitCode=results.some(r=>r.status==='FAIL')?1:0;
}
main().catch(e=>{console.error(e.message);process.exitCode=1});

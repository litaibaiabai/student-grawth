"""Regression check for run-scoped reports; no DB or product state touched."""
from pathlib import Path
import tempfile,shutil,json,subprocess,sys
base=Path(__file__).resolve().parent;root=base.parent.parent
with tempfile.TemporaryDirectory(prefix='liuyu-generator-')as t:
 r=Path(t);b=r/'demo_materials/full-system-demo';b.mkdir(parents=True)
 shutil.copy(base/'generate.py',b/'generate.py');font=r/'backend/assets/fonts';font.mkdir(parents=True);shutil.copy(root/'backend/assets/fonts/NotoSansCJKsc-Regular.otf',font)
 d=r/'docs/delivery/full-system-demo';d.mkdir(parents=True);(d/'三角色流程图.html').write_text('<html>generator test</html>')
 original=json.loads((base/'runs/20261026_dbbd8a/manifest.json').read_text())
 def gen(run):subprocess.run([sys.executable,str(b/'generate.py'),run],check=True,stdout=subprocess.DEVNULL)
 for run in ['20261026_aaaaaa','20261026_bbbbbb']:
  o=b/'runs'/run;o.mkdir(parents=True);m={**original,'runId':run,'dbName':'demo_fixture_'+run};(o/'manifest.json').write_text(json.dumps(m))
 gen('20261026_aaaaaa');a=b/'runs/20261026_aaaaaa';(a/'MCP测试报告.md').write_text('FIRST RUN PASS EVIDENCE');cases=json.loads((a/'test-cases.json').read_text());cases[0]['status']='PASS';(a/'test-cases.json').write_text(json.dumps(cases));gen('20261026_aaaaaa')
 assert (a/'MCP测试报告.md').read_text()=='FIRST RUN PASS EVIDENCE';assert json.loads((a/'test-cases.json').read_text())[0]['status']=='PASS'
 gen('20261026_bbbbbb');assert 'FIRST RUN PASS'not in (d/'MCP测试报告.md').read_text();assert '20261026_bbbbbb'in(d/'MCP测试报告.md').read_text();assert 'NOT RUN'in(d/'MCP测试报告.md').read_text();assert(a/'演示手册.pdf').exists();assert(a/'MCP测试报告.md').read_text()=='FIRST RUN PASS EVIDENCE'
 print('PASS: repeated generation preserves outcomes; new run never inherits old report; per-run manual retained')

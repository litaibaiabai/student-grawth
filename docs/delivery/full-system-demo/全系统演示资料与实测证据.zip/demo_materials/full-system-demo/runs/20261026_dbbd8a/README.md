# 三角色全系统演示资料

当前运行：`20261026_dbbd8a`；本机入口：http://localhost:5188。本机演示密码：Demo123456。

- [完整演示手册](演示手册.pdf) / [可编辑讲稿](演示手册.md)
- [三角色流程图](三角色流程图.html) / [可编辑SVG](三角色流程图.svg)
- [MCP实测报告](MCP测试报告.md)：所有结论以本轮真实记录为准。
- 素材：`demo_materials/full-system-demo/runs/20261026_dbbd8a/inputs/`（账号、策略、成绩三版、六育两版、核算、证书）
- 故事：同运行目录`stories/`；真实系统下载在`downloads/`，页面证据在`evidence/`。

启动：在项目根目录执行 `node demo_materials/full-system-demo/start.cjs 20261026_dbbd8a`。

重复演示：执行 `node demo_materials/full-system-demo/initialize.cjs` 新建库，再执行 `python3 demo_materials/full-system-demo/generate.py 新runId` 生成新资料。保留旧库及终态，关闭旧演示进程释放专用端口后再启动新runId。原业务库与现有服务保持原样。

系统真实卡片PDF在自动发卡并准备打印后产生；真实报告在发布后产生。生成器不伪造这些结果。故事建议为规则模拟；学科成绩与六育终测分别管理；期末导出为HTML打印视图。

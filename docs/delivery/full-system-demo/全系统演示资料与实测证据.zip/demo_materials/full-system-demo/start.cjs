// Run: node demo_materials/full-system-demo/start.cjs [runId]
const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'../..'),backend=path.join(root,'backend');
const id=process.argv[2]||fs.readFileSync(path.join(__dirname,'latest-run.txt'),'utf8').trim();
if(!/^\d{8}_[a-f0-9]{6}$/.test(id))throw Error('Invalid runId');
const m=JSON.parse(fs.readFileSync(path.join(__dirname,'runs',id,'manifest.json')));
const sec=JSON.parse(fs.readFileSync(path.join(__dirname,'.runtime',id,'secrets.json')));
require(path.join(backend,'node_modules/dotenv')).config({path:path.join(backend,'.env')});
Object.assign(process.env,sec,{DB_NAME:m.dbName,PORT:String(m.backendPort),NODE_ENV:'development',TZ:'Asia/Shanghai',CARD_PRINT_DIR:path.join(__dirname,'.runtime',id,'prints'),UPLOAD_DIR:path.join(__dirname,'.runtime',id,'uploads'),FRONTEND_PUBLIC_URL:m.baseUrl,CORS_ORIGIN:m.baseUrl,TRUST_PROXY:'0'});
(async()=>{
 const {createServer}=await import(path.join(root,'frontend/node_modules/vite/dist/node/index.js'));
 const server=await createServer({root:path.join(root,'frontend'),configFile:path.join(root,'frontend/vite.config.js'),server:{host:'localhost',port:m.frontendPort,strictPort:true,proxy:{'/api':{target:'http://localhost:'+m.backendPort,changeOrigin:true},'/dev-api':{target:'http://localhost:'+m.backendPort,changeOrigin:true,rewrite:p=>p.replace(/^\/dev-api/,'')}}}});
 await server.listen();require(path.join(backend,'app.js'));console.log('DEMO '+id+' '+m.baseUrl+' DB '+m.dbName);
})().catch(e=>{console.error(e.message);process.exit(1)});

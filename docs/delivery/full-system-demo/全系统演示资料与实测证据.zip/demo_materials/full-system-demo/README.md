# 全系统演示生成器

见 `docs/delivery/full-system-demo/README.md`。

先 initialize.cjs 创建独立库，再用本机有openpyxl/xlsxwriter/Pillow/reportlab的Python运行 generate.py，最后 start.cjs 启动。启动从原backend/.env读取MySQL连接，但强制替换数据库为本轮独立库，秘密仅在.runtime中。
